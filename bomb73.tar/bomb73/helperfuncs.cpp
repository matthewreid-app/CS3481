#include <string>
#include <sstream>
#include <stdint.h>
#include <stdlib.h>
#include <math.h>
#include "helperfuncs.h"
#include "hiddenhelpers.h"


std::string funFuncOne(std::string input) {
    std::string str = "";
    int val = 0;
    
    for (int i = 0; i < (int)input.length(); i++) {
        val = input[i];
        std::stringstream stream;
        stream << std::hex << val;
        std::string result( stream.str() );
        str += result;
    }
    
    return str;
}


int funFuncTwo(int num1, int num2) {
   int array1[MAX];
   int array2[MAX];
   setPhase4Array(num1, array1, MAX);
   setPhase4Array(num2, array2, MAX);
   int result = 1;
   int i;
   for (i = 0; i < MAX; i++)
   {
      if (array1[i] > 0 && array2[i] > 0)
      {
         if (array1[i] < array2[i])
         {
            result = result * pow(i, array1[i]);
         } else
         {
            result = result * pow(i, array2[i]);
         }
       }
   }
   return result; 
}

int funFuncThree(int a[], int l, int h, int i) {
    
    if (h >= l) {
        
        int m = l + (h - l) / 2;
        
        if (a[m] == i)
            return a[m];
            
        if (a[m] > i)
            return a[m] + funFuncThree(a, l, m-1, i);
        
        if (a[m] < i)
            return a[m] + funFuncThree(a, m+1, h, i);
        
    }
    return -100;
}

struct thing * newThing(int val) {
    
    struct thing *temp = (struct thing *)malloc(sizeof(struct thing));
    temp->val = val;
    temp->ptr = NULL;
    return temp;
    
}

struct thing * funFuncFour(struct thing *t, int val) {
    
    if (t == NULL) 
        return newThing(val);   
   
    struct thing * trav = t;
    while (trav->ptr != NULL) 
       trav = trav->ptr;

    trav->ptr = newThing(val);
        
    return t;
    
}

int funFuncFive(struct thing *r) {
    if (r == NULL)
        return 0;
    struct thing * trav = r; 
    int result = 0;
    while (trav != NULL) 
    {
        result += trav->val;
        trav = trav->ptr;
	if (trav != NULL) trav = trav->ptr;
    }
    return result;
}

int funFuncSix(struct thing *r) {
    if (r == NULL)
        return 0;
    struct thing * trav = r; 
    int result = 0;
    while (trav != NULL) 
    {
        trav = trav->ptr;
        if (trav != NULL) result += trav->val;
	if (trav != NULL) trav = trav->ptr;
    }
    return result;
}

int funFuncSeven(struct thing *r) {
    if (r == NULL)
        return 0;
    struct thing * trav = r; 
    int result = r->val;
    while (trav != NULL) 
    {
	if (result > trav->val) result = trav->val;
        trav = trav->ptr;
    }
    return result;
}

int funFuncEight(int num1, int num2) {
   int array1[MAX];
   int array2[MAX];
   setPhase4Array(num1, array1, MAX);
   setPhase4Array(num2, array2, MAX);
   int result = 1;
   int i;
   for (i = 0; i < MAX; i++)
   {
      if (array1[i] > 0 || array2[i] > 0)
      {
         if (array1[i] > array2[i])
         {
            result = result * pow(i, array1[i]);
         } else
         {
            result = result * pow(i, array2[i]);
         }
       }
   }
   return result;
}

